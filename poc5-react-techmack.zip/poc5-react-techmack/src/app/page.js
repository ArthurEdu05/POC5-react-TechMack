import styles from "./page.module.css";

export default function Home() {
  return (
    <>
    <header className={styles.header}>React</header>
    <div className={styles.page}>
      <h1>Estrutura de Projeto NextJS 14 ou superior</h1>
      <p>A estrutura de projeto do Next.js organiza o desenvolvimento de aplicações web em uma estrutura modular, visando facilitar
      a construção de rotas, a gestão de componentes, e a utilização de APIs e estilos. Ela segue convenções que ajudam a manter o projeto organizado, escalável e fácil de manter.</p>
      <br></br>
      <p>Aqui está um resumo detalhado sobre os principais diretórios e arquivos que compõem um projeto Next.js:</p>
      <h2 className={styles.titulo}>1. Diretório Raiz</h2>
      <p>No nível raiz, você encontrará os principais arquivos de configuração e pastas que definem o comportamento da aplicação. Entre eles temos:</p>
      <p className={styles.plist}>- <b>.gitignore: </b>Define quais arquivos ou diretórios o Git deve ignorar. É comum ignorar <b>node_modules</b>, arquivos de log, e outros arquivos temporários;</p>
      <p className={styles.plist}>- <b>package.json: </b>Gerencia as dependências do projeto e os scripts de execução como <b> npm run dev </b>para iniciar o servidor de desenvolvimento;</p>
      <p className={styles.plist}>- <b>README.md: </b>Contém informações sobre o projeto, como como configurá-lo, executá-lo e contribuir. É uma boa prática incluir instruções para outros desenvolvedores.</p>
      <br></br>
      <hr></hr>
      <h2 className={styles.titulo}>2. Diretórios Principais</h2>
      <h4 className={styles.h4}>src/app</h4>
      <br></br>
      <p><b>src:</b> O diretório src é um dos diretórios principais do Next.js.</p>
      <p><b>app: </b>Introduzido nas versões mais recentes do Next.js, o diretório <b>app</b> é o novo sistema de roteamento. Cada subdiretório dentro de <b>app</b> corresponde a uma rota. Ele permite um roteamento baseado em layout, 
      possibilitando layouts persistentes entre diferentes páginas. No diretório app, os componentes são definidos como Server Components por padrão. Isso permite criar aplicativos que abrangem tanto o servidor quanto o cliente. </p>
      <br></br>
      <h4 className={styles.h4}>globals.css</h4>
      <br></br>
      <p>Este arquivo contém estilos globais que serão aplicados a toda a aplicação. Ao incluir estilos nesse arquivo, você garante que eles afetem todas as páginas e componentes da sua aplicação Next.js.</p>
      <br></br>
      <h4 className={styles.h4}>layout.js</h4>
      <br></br>
      <p>Este arquivo define um layout que pode ser aplicado a uma ou mais páginas dentro da aplicação. O layout permite que você mantenha uma estrutura consistente, como cabeçalhos, rodapés e menus, em várias páginas sem repetir código.</p>
      <p>No Next.js, o layout.js é colocado dentro de um diretório em <b>app/</b>. Quando você define um layout, todas as páginas que estão dentro desse diretório herdarão esse layout automaticamente.</p>
      <br></br>
      <h4 className={styles.h4}>page.js</h4>
      <br></br>
      <p>Este arquivo define o conteúdo de uma página específica em seu aplicativo Next.js. Ele renderiza a interface do usuário que será exibida quando a rota correspondente for acessada. Normalmente será a página principal, como se fosse o 
      index.html
      </p>
      <br></br>
      <h4 className={styles.h4}>page.module.css</h4>
      <br></br>
      <p>Este arquivo contém estilos que são aplicados exclusivamente a uma página ou a um componente específico. A principal característica dos módulos CSS é que eles são escopados automaticamente, ou seja, as classes CSS definidas dentro desse arquivo não afetarão outras partes da aplicação, evitando conflitos de nomes. Normalmente será o estilo da página principal, 
      no caso o page.js
      </p>
      <br></br>
      <hr></hr>
      <h2 className={styles.titulo}>3. Diretórios Ignorados/Instalados</h2>
      <h4 className={styles.h4}>.next</h4>
      <br></br>
      <p>A pasta next é uma estrutura gerada pelo Next.js que contém o código necessário para compilar e executar sua aplicação. É importante notar que você não cria essa pasta manualmente; ela é gerada automaticamente durante o desenvolvimento, construção e execução do seu projeto. </p>
      <p>Essa pasta é essencial para a entrega do seu aplicativo, pois o Next.js a utiliza para gerar as páginas que serão enviadas ao cliente.</p>
      <p>*Como a pasta é gerada automaticamente, você não deve alterar ou manipular os arquivos dentro dela.*</p>
      <br></br>
      <h4 className={styles.h4}>node_modules</h4>
      <br></br>
      <p>A pasta node_modules é criada quando você instala as dependências do seu projeto usando o gerenciador de pacotes npm (install). Ela contém todos os pacotes e bibliotecas que o seu projeto precisa para funcionar corretamente.</p>
      <p>Todos os pacotes listados no arquivo package.json são instalados nessa pasta. Isso inclui não apenas o Next.js, mas também outras bibliotecas que você pode estar usando, como React</p>
      <p>A pasta geralmente é ignorada no controle de versão (Git) devido ao seu tamanho e à sua natureza gerada automaticamente. Por isso, você geralmente verá um arquivo .gitignore que inclui node_modules/. </p>
      <br></br>
      <hr className={styles.change}></hr> {/* esse hr é pra trocar o assunto/tema, ele nao deve ser igual aos hr que separam 1,2 e 3 no comeco da pagina (basicamente esses sao mais importantes)*/}
      <h1>Criação de componentes simples (sem estado)</h1>
      <h4 className={styles.h4}>O que são Componentes em React?</h4>
      <p>Os componentes são a base do React. Eles permitem que você divida a interface do usuário em partes independentes e reutilizáveis. Um componente pode ser uma função ou uma classe que 
        retorna um elemento React (geralmente JSX). Componentes simples, ou componentes de apresentação, não gerenciam estado e são usados principalmente para renderizar a interface.</p>
      <br></br>
      <p>No Next.js, os componentes são criados da mesma forma que em um aplicativo React padrão. Vamos criar um componente simples de apresentação como exemplo.</p>
      <h1 className={styles.tituloprincipal}>*FAZER CRIAÇÃO DE UM COMPONENTE SIMPLES*</h1>
      <br></br>
      <hr className={styles.change}></hr>  {/* esse hr é pra trocar o assunto/tema, ele nao deve ser igual aos hr que separam 1,2 e 3 no comeco da pagina (basicamente esses sao mais importantes)*/}
      <h2 className={styles.titulo}>Estilo CSS (global e módulo).</h2>
      <h4 className={styles.h4}>Estilos Globais</h4>
      <p>Estilos globais são regras CSS que são aplicadas a todo o aplicativo, ou seja, todos os componentes e páginas. Eles definem a aparência geral da aplicação, como cores, fontes, espaçamentos e layout. Você pode utilizar os estilos globais
      no arquivo globals.css</p>
      <br></br>
      <b>Vantagens dos Estilos Globais:</b>
      <p>- Consistência: Estilos globais garantem uma aparência consistente em todas as páginas da aplicação.</p>
      <p>- Facilidade de Uso: São simples de implementar e ideais para definir temas ou estilos universais.</p>
      <br></br>
      <h4 className={styles.h4}>Estilos de Módulo</h4>
      <p>Os módulos CSS são uma maneira de escrever estilos que são escopados a um componente específico (uma única página). Eles ajudam a evitar conflitos de nomes entre classes e tornam os estilos mais gerenciáveis.</p>
      <br></br>
      <b>Vantagens dos Estilos de Módulo:</b>
      <p>- Escopo Garantido: Os estilos são aplicados apenas aos componentes que os importam, evitando conflitos de nome.</p>
      <p>- Manutenção Facilitada: Com estilos escopados, é mais fácil entender quais estilos pertencem a quais componentes, melhorando a manutenção do código.</p>
      <p>- Reutilização de Estilos: Os módulos CSS permitem que você reutilize estilos em diferentes componentes sem preocupações com sobreposição.</p>
    </div>
    </>
  );
}
