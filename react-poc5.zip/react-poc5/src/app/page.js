import styles from "./page.module.css";
import Link from "next/link";
export default  function Home() {
  return (
    <div className={styles.App}>
      <header className={styles.AppHeader}>
      
          
          
          
   
        <h1>Eleição 2024</h1> 
        <p>Fique informado sobre as últimas novidades das eleições 2024!</p>
      </header>

      <section className={styles.imageSection}>
        <h2>Imagens dos Candidatos</h2>
        <div className={styles.images}>
          <img src="/bozo.jpg" alt="Candidatos" className="electionImage" />
          <img src="/lulinha.jpg" alt="Urna eletrônica" className="electionImage" />
        </div>
      </section>

      
    </div>
  );
}


  

