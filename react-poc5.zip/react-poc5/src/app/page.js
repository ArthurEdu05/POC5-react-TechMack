import styles from "./page.module.css";

export default function Home() {
  return (
    <div className={styles.App}>
      <header className={styles.AppHeader}>
        <h1>Eleição 2024</h1> 
        <p>Fique informado sobre as últimas novidades das eleições 2024!</p>
      </header>

      <section className={styles.imageSection}>
        <h2>Imagens dos Candidatos</h2>
        <div className={styles.images}>
          <div className={styles.imageContainer}>
            <img src="/bozo.jpg" alt="Candidato 1" className={styles.electionImage} />
          </div>
          <div className={styles.imageContainer}>
            <img src="/lulinha.jpg" alt="Candidato 2" className={styles.electionImage} />
          </div>
        </div>
      </section>
    </div>
  );
}