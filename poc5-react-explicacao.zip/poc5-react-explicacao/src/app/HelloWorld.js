export default function HelloWorld() {
    return (
      <div>
        <p>Olá, Mundo!</p>
        <p>Bem-vindo à sua aplicação Next.js!</p>
      </div>
    );
  }